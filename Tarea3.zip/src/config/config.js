
export const configuration = {
  CLIENT_API_URL: process.CLIENT_API_URL || 'http://localhost:3000',
  RECEPTION_API_URL: process.CLIENT_API_URL || 'http://localhost:3001',
  DELIVERY_API_URL: process.CLIENT_API_URL || 'http://localhost:3002',
  EBS_API_URL: process.EBS_API_URL || 'http://localhost:3003'
}
