import { ebsServer } from './ebs-server'

console.log('---------- Iniciando el EBS ------------')
console.log('Escuchando...')
ebsServer.listen()
