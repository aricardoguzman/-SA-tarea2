import { deliveryServer } from './delivery-server'

deliveryServer.listen()
deliveryServer.start()
